import React from 'react';
import "./footer.scss";

const Footer = () => {

    return (
        <div className='footerwrap'>
            Created By Bit Students 13th Generation
        </div>
    );
};

export default Footer;